# engine.py
class Engine:
    def __init__(self, tasks,engine):
      self.engine = engine
